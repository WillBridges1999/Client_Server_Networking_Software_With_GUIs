This is the 'readme.txt' file for the submission for user: 579440 (201843895), William Bridges.

This contains the client called 'location.cs' and the server called 'locationserver.cs', as specified in the ACW.

My client and server passes all the tests from all the labs- including all the extra/ additional tests. 
This can be seen via my Canvas submissions too.
This includes: Lab 0 (except the 1 test that checks what the code does with no args, but since 
adding the UI, this test shouldn't work if my code is correct), Lab 1, Lab 2, Lab 3, Lab 4, Lab 5 (with a max 
of around 750 concurrent threads), and even Lab 6 and it's extra tests.

I have implemented all the optional features (including the hashtable/ dictionary save and re-load from 
a file). My code fully passes Lab 6 (including the extra tests).

My client and server have a fully working WinForms UI, that I have tested rigorously. Any empty fields 
left, when the submit button is clicked, will be set to the default values (as specified in the ACW).

Lastly, I have some .jpg image files in the debug folder of each client/ server solution. These images
are used as the background for each of the UI's.
